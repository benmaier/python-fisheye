# fisheye

Transform single points or arrays of points using several fisheye functions.

## Install

Clone this repository

    git clone git@github.com:benmaier/fisheye.git

Install as development version (such that you don't have to reinstall after updating the repository)

    pip install -e ./fisheye --no-binary :all:

Alternatively, install as normal

    pip install ./fisheye

